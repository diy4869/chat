// import { PREVIEW } from '../mutation-types'
// export default {
//   state: {
//   },
//   actions: {

//   },
//   mutations: {
//     [PREVIEW] () {
//       console.log(1)
//     }
//   }
// }

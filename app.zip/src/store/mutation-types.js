export const SEARCH = 'search'
export const PREVIEW = 'preview'

<template>
  <div class="contacts">
    <mt-header title="联系人">
      <mt-button icon="more" slot="right"></mt-button>
    </mt-header>
  </div>
</template>

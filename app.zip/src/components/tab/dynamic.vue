<template>
  <div class="dynamic">
    <mt-header title="动态">
      <mt-button icon="more" slot="right"></mt-button>
    </mt-header>
  </div>
</template>
